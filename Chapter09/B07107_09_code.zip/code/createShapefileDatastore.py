
import requests

file = open('NaturalEarthRoads.xml','r')
payload = file.read()
file.close()
myUrl = 'http://localhost:8080/geoserver/rest/workspaces/Packt/datastores'
headers = {'content-type':'text/xml','Accept': 'text/xml'}
resp = requests.post(myUrl,auth=('admin','pwd'), data=payload, headers=headers)
print(resp.status_code)
