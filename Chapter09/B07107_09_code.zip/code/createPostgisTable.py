
import requests

myUrl = 'http://localhost:8080/geoserver/rest/workspaces/Packt/datastores/gisdata/featuretypes'
payload = '<featureType><name>ne_110m_admin</name></featureType>'
headers = {'Content-type': 'text/xml'}
resp = requests.post(myUrl, auth=('admin','pwd'), data=payload, headers=headers)
print(resp.status_code)