
import requests

urls = [
        'http://localhost:8080/geoserver/rest/workspaces/Packt/datastores/PostgisRest',
        'http://localhost:8080/geoserver/rest/workspaces/tiger/datastores/NaturalEarthRoads']
for url in urls:
    headers = {'Accept': 'text/xml'}
    resp = requests.delete(url, auth=('admin','pwd'), headers=headers)
    print(resp.status_code)