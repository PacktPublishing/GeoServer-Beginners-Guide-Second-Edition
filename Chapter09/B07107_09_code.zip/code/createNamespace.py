
import requests

myUrl = 'http://localhost:8080/geoserver/rest/namespaces'
headers = {'Content-type': 'text/xml'}
file = open('requestBody.xml','r')
payload = file.read()
resp = requests.post(myUrl, auth=('admin','geoserver'), data=payload, headers=headers)
ptint(resp.status_code)