
import requests

myUrl =  'http://localhost:8080/geoserver/rest/namespaces/newWorkspace'
file = open('requestBody.xml','r')
payload = file.read()
headers = {'Content-type': 'text/xml'}
resp = requests.put(myUrl, auth=('admin','pwd'), data=payload, headers=headers)
print(resp.status_code)
