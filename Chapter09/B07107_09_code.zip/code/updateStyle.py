
import requests

myUrl = 'http://localhost:8080/geoserver/rest/styles'
file = open(PopulatedPlacesBlueLabeled.xml','r')
payload = file.read()
headers = {'Content-type': 'application/vnd.ogc.sld+xml'}
resp = requests.post(myUrl, auth=('admin','pwd'), data=payload, headers=headers)
print(resp.status_code)