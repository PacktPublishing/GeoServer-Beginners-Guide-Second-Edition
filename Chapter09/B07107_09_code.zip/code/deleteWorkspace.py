import requests

myUrl = 'http://localhost:8080/geoserver/rest/workspaces/newWorkspace'
headers = {'Accept': 'text/xml'}
resp = requests.delete(myUrl, auth=('admin','pwd'), headers=headers)
print(resp.status_code)
