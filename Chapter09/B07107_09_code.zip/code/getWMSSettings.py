
import requests

myUrl = 'http://localhost:8080/geoserver/rest/services/wms/settings'
headers = {'Accept: text/xml'}
resp = requests.get(myUrl, auth=('admin','pwd'), headers=headers)
if resp.status_code == 200:
    file = open('wmsSettings.xml','w')
    file.write(resp.text)
    file.close()