
import requests

myUrl = 'http://localhost:8080/geoserver/rest/layers/ne_50m_populated_places'
headers = {'Accept: text/xml'}
resp = requests.get(myUrl, auth=('admin','pwd'), headers=headers)
if resp.status_code == 200:
    file = open('ne_50m_populated_places.xml','w')
    file.write(resp.text)
    file.close()