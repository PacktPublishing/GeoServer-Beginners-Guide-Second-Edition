
import requests

myUrl = 'http://localhost:8080/geoserver/rest/styles/PopulatedPlacesLabeled'
headers = {'Accept: application/vnd.ogc.sld+xml'}
resp = requests.get(myUrl, auth=('admin','pwd'), headers=headers)
if resp.status_code == 200:
    file = open('PopulatedPlacesBlueLabeled.xml','w')
    file.write(resp.text)
    file.close()